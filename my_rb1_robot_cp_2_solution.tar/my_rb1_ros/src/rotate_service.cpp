#include "ros/ros.h"
#include <cmath> // Include for M_PI constant
#include <geometry_msgs/Twist.h>
#include <nav_msgs/Odometry.h>
#include <tf/tf.h>

#include <my_rb1_msgs/Rotate.h>

class RobotRotateService {

public:
  // ROS Objects
  ros::NodeHandle nh_;

  // ROS Services
  ros::ServiceServer robot_rotate_service;

  // ROS Subscribers
  ros::Subscriber odom_sub;

  // ROS Publishers
  ros::Publisher vel_pub;

  // ROS Messages
  geometry_msgs::Twist vel_msg;

  // Constructor
  RobotRotateService() : yaw(0.0), yaw_old(0.0) {

    // Advertise the rotate_robot service
    robot_rotate_service = nh_.advertiseService(
        "/rotate_robot", &RobotRotateService::my_callback, this);
    ROS_INFO("Service Ready: /rotate_robot");

    // Subscribe to the odometry topic
    odom_sub =
        nh_.subscribe("odom", 1000, &RobotRotateService::odomCallback, this);

    // Advertise the cmd_vel publisher
    vel_pub = nh_.advertise<geometry_msgs::Twist>("/cmd_vel", 1);
  }

  // Callback for the odometry topic
  void odomCallback(const nav_msgs::Odometry::ConstPtr &msg) {
    tf::Pose pose;
    tf::poseMsgToTF(msg->pose.pose, pose);
    // Extract yaw angle from the pose
    yaw = tf::getYaw(pose.getRotation());
  }

  // Callback for the rotate_robot service
  bool my_callback(my_rb1_msgs::Rotate::Request &req,
                   my_rb1_msgs::Rotate::Response &res) {
    ROS_INFO("Service Requested: /rotate_robot");

    double distance = 0.0;

    // Set angular velocity for rotation
    vel_msg.angular.z =
        -0.5 * (static_cast<float>(req.degrees) / std::abs(req.degrees));
    vel_pub.publish(vel_msg);

    // Record initial yaw for distance calculation
    yaw_old = std::abs(yaw);

    // Rotate until the specified angle is reached
    while (distance < std::abs(req.degrees)) {
      // Calculate distance traveled in radians
      double distance_rad = std::abs(std::abs(yaw) - yaw_old);
      // Accumulate distance in degrees
      distance += (180.0 / M_PI) * distance_rad;
      // Update the old yaw for the next iteration
      yaw_old = std::abs(yaw);

      // Allow other ROS callbacks to be processed
      ros::spinOnce();
    }

    // Stop the rotation
    vel_msg.angular.z = 0.0;
    vel_pub.publish(vel_msg);

    // Set service response
    res.result = "Service Response :: /rotate_robot : Rotation Successful!";
    ROS_INFO("Service Completed: /rotate_robot");
    return true;
  }

private:
  // Variables to track yaw angles
  double yaw;
  double yaw_old;
};

int main(int argc, char **argv) {
  // Initialize ROS node
  ros::init(argc, argv, "rotate_robot_service_node");

  // Create RobotRotateService object
  RobotRotateService service;

  // Enter ROS event loop
  ros::spin();

  return 0;
}
